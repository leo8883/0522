from django.contrib import admin
from .models import selfIntroduction

# Register your models here.

class selfIntroductionAdmin(admin.ModelAdmin):
	list_display = ('name', 'address', 'personality')

admin.site.register(selfIntroduction)