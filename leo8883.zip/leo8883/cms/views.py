from django.shortcuts import render_to_response
# Create your views here.
from .models import selfIntroduction

def index(request):
	selfIntro = selfIntroduction.objects.all()
	return render_to_response('cms/menu.html',locals())
